/*Para desenhar no Canvas , é preciso um script após ele ter sido carregado.
    Nesse script obteremos o contexto gráfico, que é o objeto que realiza de fato
    as tarefas de desenho no canvas*/




